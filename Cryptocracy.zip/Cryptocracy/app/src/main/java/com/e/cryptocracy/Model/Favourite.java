package com.e.cryptocracy.Model;

public class Favourite {
    String coinId;

    public Favourite(String coinId) {
        this.coinId = coinId;
    }

    public String getCoinId() {
        return coinId;
    }
}
