package com.e.cryptocracy;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.e.cryptocracy.Adapter.ViewPagerAdapter;
import com.e.cryptocracy.Fragments.CoinFragment;
import com.e.cryptocracy.Fragments.ExchangeFragment;
import com.e.cryptocracy.Fragments.ExchangeInfo;
import com.e.cryptocracy.Fragments.ExchangeMarket;
import com.e.cryptocracy.Fragments.FavouriteFragment;
import com.e.cryptocracy.Interface.RetrofitService;
import com.e.cryptocracy.Model.ExchangeDetailModel;
import com.google.firestore.v1beta1.TransactionOptionsOrBuilder;
import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ExchangeActivity extends AppCompatActivity {

    TextView exchangeName;
    private ImageView ExchangeImage;
    private String EXCHANGE_ID;
    private String EXCHANGE_URL;
    private String EXCHANGE_NAME;

    private ViewPager pager;
    private ViewPagerAdapter pagerAdapter;
    private TabLayout tabLayout;
    public static TextView trade_volume_24h_btc;
    public static TextView trust_score_rank;
    public static TextView trade_volume_24h_btc_normalized;
    public static TextView centralized;
    public static TextView trust_score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_exchange );
        Toolbar toolbar = findViewById( R.id.toolbar );
        setSupportActionBar( toolbar );

        getSupportActionBar().setDisplayHomeAsUpEnabled( true );
        getSupportActionBar().setDisplayShowHomeEnabled( true );

        exchangeName = (TextView) toolbar.findViewById( R.id.textView2 );
        trade_volume_24h_btc = (TextView) findViewById( R.id.textView );
        trust_score_rank = (TextView) findViewById( R.id.textView12 );
        trade_volume_24h_btc_normalized = (TextView) findViewById( R.id.textView11 );
        centralized = (TextView) findViewById( R.id.textView15 );
        trust_score = (TextView) findViewById( R.id.textView16 );
        ExchangeImage = (ImageView) toolbar.findViewById( R.id.imageView4 );

        if (getIntent().hasExtra( "exchangeId" )) {
            EXCHANGE_ID = getIntent().getStringExtra( "exchangeId" );
            EXCHANGE_NAME = getIntent().getStringExtra( "exchangeName" );
            EXCHANGE_URL = getIntent().getStringExtra( "exchangeImageUrl" );
            if (EXCHANGE_URL != null)
                Picasso.with( this ).load( EXCHANGE_URL ).into( ExchangeImage );
            exchangeName.setText( EXCHANGE_NAME );

            setFragment();

            setDetail( EXCHANGE_ID );

        }


    }

    private void setDetail(String exchange_id) {

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    private void setFragment() {
        tabLayout = (TabLayout) findViewById( R.id.ex_tabs );
        pager = (ViewPager) findViewById( R.id.ex_view_pager );
        pagerAdapter = new ViewPagerAdapter( getSupportFragmentManager() );
        pagerAdapter.Addfragment( new ExchangeMarket( ExchangeActivity.this, EXCHANGE_ID ), "Market" );
        pagerAdapter.Addfragment( new ExchangeInfo( ExchangeActivity.this ), "Info" );

        pager.setAdapter( pagerAdapter );
        tabLayout.setupWithViewPager( pager );

    }
}
