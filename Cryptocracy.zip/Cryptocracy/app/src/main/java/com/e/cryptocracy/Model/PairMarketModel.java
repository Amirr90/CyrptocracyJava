package com.e.cryptocracy.Model;

public class PairMarketModel {
}
