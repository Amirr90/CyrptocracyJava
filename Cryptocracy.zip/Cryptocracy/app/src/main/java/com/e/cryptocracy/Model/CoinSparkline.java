package com.e.cryptocracy.Model;

import java.util.List;

public class CoinSparkline {
    List<Float>price;

    public List<Float> getPrice() {
        return price;
    }
}
