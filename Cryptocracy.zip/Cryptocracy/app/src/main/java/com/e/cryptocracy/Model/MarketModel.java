package com.e.cryptocracy.Model;

public class MarketModel {
    private String name;
    private String identifier;

    public String getIdentifier() {
        return identifier;
    }

    public String getName() {
        return name;
    }
}
