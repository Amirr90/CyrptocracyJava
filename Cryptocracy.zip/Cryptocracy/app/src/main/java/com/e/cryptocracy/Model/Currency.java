package com.e.cryptocracy.Model;

import java.util.List;

public class Currency {

    List<CurrencyData>rates;

    public List<CurrencyData> getRates() {
        return rates;
    }
}
