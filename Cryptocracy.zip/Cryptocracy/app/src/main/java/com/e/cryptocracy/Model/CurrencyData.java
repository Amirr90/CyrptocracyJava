package com.e.cryptocracy.Model;

public class CurrencyData {
    private String name;
    private String unit;
    private String type;
    private float value;

    public String getName() {
        return name;
    }

    public String getUnit() {
        return unit;
    }

    public String getType() {
        return type;
    }

    public float getValue() {
        return value;
    }
}
