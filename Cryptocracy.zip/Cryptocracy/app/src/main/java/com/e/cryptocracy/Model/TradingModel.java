package com.e.cryptocracy.Model;

public class TradingModel {

   private String image;

    public String getImage() {
        return image;
    }
}
